#SHOW TABLES
## keyword
SHOW, TABLE


