# utils/validators.py
import pandas as pd

def validate_inputs(*series_list):
    """
    验证多个 pd.Series 是否长度一致、非空、无全 NaN
    """
    if not series_list:
        return pd.Series([], dtype=bool)
    
    n = len(series_list[0])
    for s in series_list:
        if len(s) != n:
            raise ValueError("Input series must have the same length")
    
    valid = pd.Series([True] * n)
    for s in series_list:
        valid &= s.notna()
    return valid

