# models/ltv_calculator.py
import pandas as pd
import numpy as np
from ..utils.validators import validate_inputs
from ..features.recency import compute_recency_score
from ..features.frequency import compute_frequency_score
from ..features.monetary import compute_monetary_score

def calculate_ltv(
    days_since_last_action: pd.Series,
    total_actions: pd.Series,
    total_spend: pd.Series
) -> pd.Series:
    """
    计算 LTV 分数（0~100）
    """
    valid = validate_inputs(days_since_last_action, total_actions, total_spend)
    valid &= (
        (days_since_last_action >= 0) &
        (total_actions >= 0) &
        (total_spend >= 0)
    )

    result = pd.Series([np.nan] * len(days_since_last_action), dtype='float64')
    if not valid.any():
        return result

    d = days_since_last_action[valid].values
    a = total_actions[valid].values
    s = total_spend[valid].values

    r_score = compute_recency_score(d)
    f_score = compute_frequency_score(a)
    m_score = compute_monetary_score(s)

    ltv = r_score * 40 + f_score * 30 + m_score * 30
    ltv = np.clip(ltv, 0, 100)

    result.loc[valid] = ltv
    return result

