# features/recency.py
import numpy as np

def compute_recency_score(days_since_last: np.ndarray) -> np.ndarray:
    """Recency: 7天内为1，30天外为0，线性衰减"""
    return np.clip((30 - days_since_last) / 23.0, 0, 1)

