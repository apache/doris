# features/monetary.py
import numpy as np

def compute_monetary_score(total_spend: np.ndarray) -> np.ndarray:
    """Monetary: spend / 1000"""
    return total_spend / 1000.0

