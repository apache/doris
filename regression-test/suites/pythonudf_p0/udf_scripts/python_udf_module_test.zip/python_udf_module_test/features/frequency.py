# features/frequency.py
import numpy as np

def compute_frequency_score(total_actions: np.ndarray) -> np.ndarray:
    """Frequency: log(1 + actions) / 10"""
    return np.log1p(total_actions) / 10.0

