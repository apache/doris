import pandas as pd
from .models.ltv_calculator import calculate_ltv

# 可选：重命名或包装（保持接口清晰）
def safe_ltv(
    days_since_last_action: pd.Series,
    total_actions: pd.Series,
    total_spend: pd.Series
):
    return calculate_ltv(days_since_last_action, total_actions, total_spend)

