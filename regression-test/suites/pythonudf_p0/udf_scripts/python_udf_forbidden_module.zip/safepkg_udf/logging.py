def evaluate(a):
    """A valid packaged UDF whose middle module name is forbidden-like."""
    if a is None:
        return None
    return a + 10
