def evaluate(a):
    """A UDF module that shadows the built-in logging module."""
    if a is None:
        return None
    return a + 1
