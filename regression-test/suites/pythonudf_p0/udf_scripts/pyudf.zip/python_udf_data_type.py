def row_to_csv_all_impl(
    bool_col, tinyint_col, smallint_col, int_col, bigint_col, largeint_col,
    float_col, double_col, decimal32_col, decimal64_col, decimal128_col,
    date_col, datetime_col, char_col, varchar_col, string_col
):
    cols = [
        bool_col, tinyint_col, smallint_col, int_col, bigint_col, largeint_col,
        float_col, double_col, decimal32_col, decimal64_col, decimal128_col,
        date_col, datetime_col, char_col, varchar_col, string_col
    ]
    
    def safe_str(x):
        return 'NULL' if x is None else str(x)
    
    return ','.join(safe_str(col) for col in cols)