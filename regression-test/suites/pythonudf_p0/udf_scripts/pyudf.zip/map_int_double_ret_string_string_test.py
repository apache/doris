def evaluate(i, d):
    ans = {}
    ans["114" + str(i)] = "514" + str(d)
    return ans