def map_to_csv_impl(map1, map2):
    def safe_str(x):
        return 'NULL' if x is None else str(x)
    
    def format_map(m):
        if m is None:
            return 'NULL'
        # Doris passes MAP as Python dict
        items = [f"{safe_str(k)}:{safe_str(v)}" for k, v in m.items()]
        return '{' + ','.join(sorted(items)) + '}'
    
    return '|'.join([format_map(map1), format_map(map2)])