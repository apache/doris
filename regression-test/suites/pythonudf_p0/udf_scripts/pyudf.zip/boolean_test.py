def evaluate(arg):
    if arg is True:
        return False
    else:
        return True