def evaluate(mp):
    ans = {}
    for key, value in mp.items():
        ans[key + "114"] = value + "514"
    return ans