def array_to_csv_impl(int_arr, str_arr, nested_arr):
    def safe_str(x):
        return 'NULL' if x is None else str(x)
    
    def format_array(arr):
        if arr is None:
            return 'NULL'
        return '[' + ','.join(safe_str(item) for item in arr) + ']'
    
    def format_nested_array(arr):
        if arr is None:
            return 'NULL'
        return '[' + ','.join(format_array(inner) for inner in arr) + ']'
    
    parts = [
        format_array(int_arr),
        format_array(str_arr),
        format_nested_array(nested_arr)
    ]
    return '|'.join(parts)
