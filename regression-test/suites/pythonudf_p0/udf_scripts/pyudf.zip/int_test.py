def evaluate(arg):
    return int(arg + 1)