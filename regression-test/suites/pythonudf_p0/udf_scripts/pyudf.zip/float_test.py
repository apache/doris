def evaluate(arg1, arg2):
    return arg1 - arg2