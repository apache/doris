class ForbiddenUDAF:
    """A UDAF module that shadows the built-in pathlib module."""

    def __init__(self):
        self.total = 0

    def accumulate(self, value):
        if value is not None:
            self.total += value

    def merge(self, other_state):
        if other_state is not None:
            self.total += other_state

    def finish(self):
        return self.total

    @property
    def aggregate_state(self):
        return self.total
