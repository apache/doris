# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

import pickle


class SumAgg:
    def __init__(self):
        self.sum = 0

    def init(self):
        self.sum = 0

    @property
    def aggregate_state(self):
        return self.sum

    def accumulate(self, val):
        if val is not None:
            self.sum += val

    def merge(self, other_state):
        if other_state is not None:
            self.sum += other_state

    def serialize(self):
        return pickle.dumps(self.sum)

    def deserialize(self, data):
        self.sum = pickle.loads(data)

    def finish(self):
        return self.sum + 1000
