def forbidden_udtf(value):
    """A UDTF module that shadows the built-in ipaddress module."""
    if value is not None:
        yield (value, value * 2)
