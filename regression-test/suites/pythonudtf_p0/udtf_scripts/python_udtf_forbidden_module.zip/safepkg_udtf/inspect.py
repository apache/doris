def safe_udtf(value):
    """A valid packaged UDTF whose middle module name is forbidden-like."""
    if value is not None:
        yield (value, value + 10)
