DELETE from ${table} where L_ORDERKEY >= 0;

